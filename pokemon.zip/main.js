$(document).ready(function(){

    for(i=1;i<=151;i++){
        $('.pokemon').append('<div class="col-md-2"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/'+i+'.png" alt=""></div>');
    }
});